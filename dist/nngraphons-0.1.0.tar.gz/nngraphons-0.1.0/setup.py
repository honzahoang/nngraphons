# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['nngraphons',
 'nngraphons.architectures',
 'nngraphons.data_loading',
 'nngraphons.learning',
 'nngraphons.visualization']

package_data = \
{'': ['*']}

install_requires = \
['matplotlib', 'networkx', 'numpy', 'pandas', 'scipy', 'torch>=1.4,<2.0']

setup_kwargs = {
    'name': 'nngraphons',
    'version': '0.1.0',
    'description': '',
    'long_description': None,
    'author': 'Huy Hoang Vu',
    'author_email': 'you@example.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.6,<4.0',
}


setup(**setup_kwargs)
